/*
Trevor Ralston CSCI 6626 Cant Stop
This is supposed to implement a game for the game "Can't stop"
*/

#include "board.hpp"
#include "column.hpp"
#include "dice.hpp"
#include "enums.hpp"
#include "game.hpp"
#include "player.hpp"
#include "tools.hpp"

int main() {
  banner();
  Game game;

  bye();
  return 0;
}