#include "enums.hpp"

const char* ECcolorArr[] = {"WHITE","ORANGE","YELLOW","GREEN","BLUE"};

const string EStateStrings[] = {"AVAILABLE", "PENDING", "CAPTURED"};